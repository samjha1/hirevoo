# Synthetic catalog SQL (10k goals + 20k jobs)

## Generate files

From the `hirevo` project root:

```bash
php database/scripts/generate-synthetic-catalog-sql.php
```

This creates:

| Files | Rows |
|-------|------|
| `00_setup_catalog_employer.sql` | Catalog employer user + profile |
| `job_roles_part_01.sql` … `part_20.sql` | **10,000** job goals (`is_synthetic = 1`) |
| `employer_jobs_part_01.sql` … `part_40.sql` | **20,000** active jobs |

Slugs: `syn-goal-00001` … `syn-job-20000` (no collisions with real data).

## Import on server

### Option A — PHP (recommended on shared hosting)

```bash
php database/scripts/generate-synthetic-catalog-sql.php   # locally or on server
php database/scripts/import-synthetic-catalog-sql.php
```

### Option B — MySQL CLI

```bash
cd database/sql/synthetic
mysql -u USER -p DATABASE < 00_setup_catalog_employer.sql
mysql -u USER -p DATABASE < job_roles_part_01.sql
# … repeat for all parts
```

### Option C — Artisan seeders (no SQL files)

```bash
php artisan hirevo:seed-synthetic-catalog
```

## Catalog employer account

- **Email:** `catalog-employer@hirevo.com`
- **Password:** `ChangeMeCatalog!` (change after import)

## Notes

- Run migrations first (`job_roles.is_synthetic`, `open_roles_count`, etc.).
- If goals/jobs already exist, seeder skips; SQL always inserts (may duplicate slugs — import on empty catalog or truncate synthetic rows first).
- Total SQL size ≈ 15–25 MB.
